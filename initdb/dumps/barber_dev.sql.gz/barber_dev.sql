-- MySQL dump 10.13  Distrib 5.7.36, for Linux (x86_64)
--
-- Host: localhost    Database: barber_dev
-- ------------------------------------------------------
-- Server version	5.7.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alembic_version`
--

DROP TABLE IF EXISTS `alembic_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alembic_version` (
  `version_num` varchar(32) NOT NULL,
  PRIMARY KEY (`version_num`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alembic_version`
--

LOCK TABLES `alembic_version` WRITE;
/*!40000 ALTER TABLE `alembic_version` DISABLE KEYS */;
INSERT INTO `alembic_version` VALUES ('ce4cbffe9af0');
/*!40000 ALTER TABLE `alembic_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group`
--

DROP TABLE IF EXISTS `group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `name` varchar(256) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group`
--

LOCK TABLES `group` WRITE;
/*!40000 ALTER TABLE `group` DISABLE KEYS */;
INSERT INTO `group` VALUES (1,'2022-01-14 19:32:52','2022-01-14 19:32:52',NULL,'System',1),(2,'2022-01-14 19:32:52','2022-01-14 19:32:52',NULL,'Admin',1),(3,'2022-01-14 19:32:52','2022-01-14 19:32:52',NULL,'Barber Admin',1),(4,'2022-01-14 19:32:52','2022-01-14 19:32:52',NULL,'Employee',1),(5,'2022-01-14 19:32:52','2022-01-14 19:32:52',NULL,'Client',1);
/*!40000 ALTER TABLE `group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `name` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `password` varchar(256) NOT NULL,
  `taxpayer_id` varchar(16) NOT NULL,
  `birth_date` varchar(16) NOT NULL,
  `hash_id` varchar(36) NOT NULL,
  `email_verified` tinyint(1) DEFAULT '0',
  `token_update` varchar(36) DEFAULT NULL,
  `cell_phone` varchar(32) DEFAULT NULL,
  `genre` varchar(256) DEFAULT NULL,
  `image_key` varchar(256) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `taxpayer_id` (`taxpayer_id`),
  UNIQUE KEY `hash_id` (`hash_id`),
  KEY `group_id` (`group_id`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'2022-01-14 19:32:13','2022-01-14 19:32:13',NULL,'Usuário Admin','usarioadmin@email.com','$pbkdf2-sha256$29000$11rr/d.7F8J4j5HS2ntvDQ$9Z4.wll26veFi9EUDTnvl9GIXz6vuRXYuh7NxumaBko','121.359.980-60','05/11/1997','6dcf0b17-041d-4bf5-8d45-66841c5ce96d',0,'75cdf94e-8f63-4f81-8523-9d73e0006e9c','62999999999',NULL,NULL,1,2),(6,'2022-01-14 19:41:41','2022-01-14 19:41:41',NULL,'Usuário Barber Admin','usariobarberadmin@email.com','$pbkdf2-sha256$29000$UAqBcK71HiPEuNd6j/Feaw$yRc24R4nuqTOZHeV.KWd3XMuOrAGg9g3ADjGhyjoGO8','837.537.090-85','05/11/1997','3d60ae27-6579-473b-ad3c-696381579e73',0,'96b8c93b-3814-4007-88cf-b6ffbdcee6d5','62999999999',NULL,NULL,1,2),(7,'2022-01-14 19:41:41','2022-01-14 19:41:41',NULL,'Usuário Employee','usarioemployee@email.com','$pbkdf2-sha256$29000$PGdsrTWGECIkZOy9l7LWOg$FY.CK3HhRMj7qJHP98zIIFQbnRMcPJS0DcGJrfMtyFA','855.358.030-06','05/11/1997','a60c2463-3939-4dae-989b-3df29d754bed',0,'ee66281b-db3a-437f-aff8-09786e2d988c','62999999999',NULL,NULL,1,2),(8,'2022-01-14 19:41:41','2022-01-14 19:41:41',NULL,'Usuário Client','usarioclient@email.com','$pbkdf2-sha256$29000$wzjnHEOIUYrRWovRuldqbQ$0ASGpccx1s8jtw4sA7e5.GpOW5ipy1hkqJ2EUuWzRlg','027.053.450-43','05/11/1997','eeb09670-99f4-4357-b421-0767b30a1a17',0,'6b8ab13b-cb69-46f3-af50-3b7b32eb5e45','62999999999',NULL,NULL,1,2);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-14 22:43:50
